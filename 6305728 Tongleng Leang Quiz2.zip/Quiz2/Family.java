package Quiz2;
class Family
{
    public static void main(String[] args)
    {   
        Human bob = new Human();
        Human wife = new Human();

        bob.height = 1.8;
        bob.balance = 100;
        wife.height = 1.6;
        wife.balance = 10000;
        wife = bob;

        bob.humanBalance();
        bob.humanTall();

        wife.humanBalance();
        wife.humanTall();
    }
}