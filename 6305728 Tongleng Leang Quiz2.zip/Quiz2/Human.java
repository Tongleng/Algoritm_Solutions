package Quiz2;
class Human
{
    public double balance;
    public double height;

    public void humanBalance()
    {
        System.out.println(balance + "$");
    }

    public void humanTall()
    {
        System.out.println(height + "m");
    }
}